package modul06;

public class Queue<T> {

}
