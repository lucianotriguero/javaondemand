package modul02;

/**
     * Course: Javaprogrammering
     * Modul 2
     * Purpose: Material till lektioner
     * (c) Luciano Triguero, 2023 
     */

public class ExempelModuloApp {

    /**
         * Starts the Java application
         * @param args command lines paramters
    */
    public static void main(String[] args) throws Exception {

        int a = 72;
        int b = 63;
        System.out.println("Division a/b ger: " + a/b);
        System.out.println(  "Molulo a%b ger: " + a%b);

        a = 2;
        b= 10;
        System.out.println("Division a/b ger: " + a/b);
        System.out.println(  "Molulo a%b ger: " + a%b);

    }   
    
}
