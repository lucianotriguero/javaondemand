package modul01;

/*
     * Course: Javaprogrammering
     * Modul 1
     * Purpose: Material till lektioner
     * (c) Luciano Triguero, june 2023 
*/

public class Goodbye {
    public static void main(String[] args) {
        System.out.print("Goodbye, ");
        System.out.println("cruel world");
    }
}
