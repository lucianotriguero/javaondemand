package modul01;

/*
     * Course: Javaprogrammering
     * Modul 1
     * Purpose: Material till lektioner
     * (c) Luciano Triguero, 2023 
*/

public class WorkingWithVariablesApp {
	
	public static void main(String[] args) {
		String welcomeText = "Today is: ";
		int day = 28;
		int month = 3;
		int year = 2023;
		char punkt = '.';
		
		System.out.print("God morning! ");
		System.out.print(welcomeText);
		System.out.print(year);
		System.out.print("-");
		System.out.print(month);
		System.out.print("-");
		System.out.print(day);
		System.out.println(punkt);		
	}	
}
