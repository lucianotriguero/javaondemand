package modul01;

/*
     * Course: Javaprogrammering
     * Modul 1
     * Purpose: Material till lektioner
     * (c) Luciano Triguero, 2023 
*/

public class MainClassApp {
    public static void main(String[] args) {
        System.out.println("Welcome to JAVA OnDemand");
    }
}
